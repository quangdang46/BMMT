import cv2
import os

source_image = cv2.imread("test.BMP")
score = 0
file_name = None
image = None
kp1, kp2, mp = None, None, None
db_name = "db"

for file in os.listdir(db_name):
    target_image = cv2.imread(os.path.join(db_name, file))

    sift = cv2.SIFT_create()
    kp1, des1 = sift.detectAndCompute(source_image, None)
    kp2, des2 = sift.detectAndCompute(target_image, None)
    matches = cv2.FlannBasedMatcher(dict(algorithm=1, trees=10), dict()).knnMatch(des1, des2, k=2)

    mp = []
    for p, q in matches:
        if p.distance < 0.1 * q.distance:
            mp.append(p)

    keypoints = min(len(kp1), len(kp2))
    if keypoints > 0:
        current_score = len(mp) / keypoints * 100
        if current_score > score:
            score = current_score
            file_name = file
            image = target_image

result = cv2.drawMatches(source_image, kp1, image, kp2, mp, None)
result = cv2.resize(result, None, fx=2.5, fy=2.5)
cv2.imshow("result", result)
cv2.waitKey(0)
cv2.destroyAllWindows()

print(f"The best match: {file_name}")
print(f"The score: {score}")

